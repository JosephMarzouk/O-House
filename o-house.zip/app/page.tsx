'use client'

import { useState } from 'react'
import {
  ArrowLeft, ArrowRight, Bell, Check, CheckCircle2, ChevronRight, ClipboardCheck,
  CloudOff, Filter, Home, ImagePlus, Languages, LockKeyhole, Menu, Search,
  Settings, ShieldCheck, UserRound, WifiOff, X, PenLine, Clock3, MapPin,
} from 'lucide-react'

type View = 'login' | 'home' | 'assignments' | 'detail' | 'signature' | 'success'
type Item = { name: string; done: boolean; required?: boolean; photo?: boolean; rejected?: string }

const assignments = [
  { title: 'Morning Cleaning Round', place: 'Main Sports Club', time: '08:00 – 10:30', progress: '3/7 done', status: 'In progress', tone: 'progress' },
  { title: 'Locker Rooms', place: 'West Wing', time: '11:00 – 12:30', progress: '0/5 done', status: 'Pending', tone: 'pending' },
  { title: 'Reception & Lobby', place: 'Club House', time: 'Yesterday · 14:00', progress: '8/8 done', status: 'Approved', tone: 'approved' },
]

const initialItems: Item[] = [
  { name: 'Main entrance & reception', done: true, photo: true },
  { name: 'Men’s changing room', done: true, required: true, photo: true },
  { name: 'Women’s changing room', done: true, required: true },
  { name: 'Gym floor', done: false, required: true },
  { name: 'Showers & toilets', done: false, required: true, photo: true, rejected: 'Please retake photo: floor still appears wet.' },
  { name: 'Staff corridor', done: false },
  { name: 'Waste collection point', done: false, required: true },
]

function Logo() { return <div className="brand-mark" aria-label="O House"><span>O</span><i /></div> }
function StatusChip({ children, tone }: { children: React.ReactNode; tone: string }) { return <span className={`chip chip-${tone}`}>{children}</span> }

export default function Page() {
  const [view, setView] = useState<View>('home')
  const [rtl, setRtl] = useState(false)
  const [items, setItems] = useState(initialItems)
  const [tab, setTab] = useState('Today')
  const [signature, setSignature] = useState(false)
  const [showProfile, setShowProfile] = useState(false)
  const completed = items.filter((item) => item.done).length
  const allDone = items.filter((item) => item.required).every((item) => item.done)
  const toggle = (index: number) => setItems((current) => current.map((item, i) => i === index ? { ...item, done: !item.done } : item))

  if (view === 'login') return <Login onLogin={() => setView('home')} rtl={rtl} setRtl={setRtl} />
  if (view === 'success') return <Success onBack={() => setView('assignments')} />

  return (
    <main className="app-viewport">
      <div className="app-shell" dir={rtl ? 'rtl' : 'ltr'}>
        {view === 'home' && <HomeView onOpen={() => setView('assignments')} onProfile={() => setShowProfile(true)} />}
        {view === 'assignments' && <AssignmentsView tab={tab} setTab={setTab} onBack={() => setView('home')} onOpen={() => setView('detail')} />}
        {view === 'detail' && <DetailView rtl={rtl} setRtl={setRtl} items={items} completed={completed} allDone={allDone} toggle={toggle} onBack={() => setView('assignments')} onSubmit={() => setView('signature')} />}
        {view === 'signature' && <SignatureView rtl={rtl} signature={signature} setSignature={setSignature} onBack={() => setView('detail')} onSubmit={() => setView('success')} />}
        {view !== 'detail' && view !== 'signature' && <BottomNav active={view} onHome={() => setView('home')} onAssignments={() => setView('assignments')} onProfile={() => setShowProfile(true)} />}
        {showProfile && <Profile onClose={() => setShowProfile(false)} rtl={rtl} setRtl={setRtl} onLogout={() => { setShowProfile(false); setView('login') }} />}
      </div>
    </main>
  )
}

function Login({ onLogin, rtl, setRtl }: { onLogin: () => void; rtl: boolean; setRtl: (v: boolean) => void }) {
  return <main className="login-page" dir={rtl ? 'rtl' : 'ltr'}><div className="login-card"><Logo /><p className="eyebrow">STAFF OPERATIONS</p><h1>Welcome back</h1><p className="subtle">Sign in to continue your cleaning rounds.</p><div className="language-toggle"><button className={!rtl ? 'selected' : ''} onClick={() => setRtl(false)}>English</button><button className={rtl ? 'selected' : ''} onClick={() => setRtl(true)}>العربية</button></div><label>Phone number<div className="input-row"><span>+966</span><input placeholder="50 123 4567" aria-label="Phone number" /></div></label><label>Password<div className="input-row"><LockKeyhole size={18} /><input type="password" placeholder="Enter your password" aria-label="Password" /></div></label><button className="primary-button" onClick={onLogin}>Sign in <ArrowRight size={18} /></button><button className="text-button">Forgot password?</button></div></main>
}

function Header({ title, onBack, action }: { title?: string; onBack?: () => void; action?: React.ReactNode }) { return <header className="topbar">{onBack ? <button className="icon-button" onClick={onBack} aria-label="Go back"><ArrowLeft size={21} /></button> : <Logo />}<strong>{title}</strong><div className="topbar-actions">{action || <button className="icon-button" aria-label="Notifications"><Bell size={20} /></button>}</div></header> }

function HomeView({ onOpen, onProfile }: { onOpen: () => void; onProfile: () => void }) { return <section className="screen"><Header action={<button className="avatar" onClick={onProfile}>AS</button>} /><div className="scroll-content"><div className="welcome"><div><p className="eyebrow">TUESDAY, 26 AUGUST</p><h1>Good morning,<br /><span>Ahmed.</span></h1></div><div className="weather">28°<small>Riyadh</small></div></div><div className="offline-banner"><WifiOff size={18} /><div><b>Working offline</b><span>3 changes pending sync</span></div><ChevronRight size={18} /></div><div className="stat-grid"><Stat number="4" label="To do" tone="neutral" /><Stat number="1" label="In progress" tone="teal" /><Stat number="12" label="Submitted" tone="green" /><Stat number="2" label="Overdue" tone="red" /></div><div className="section-heading"><h2>Today’s work</h2><button className="link-button" onClick={onOpen}>View all <ArrowRight size={15} /></button></div><button className="hero-task" onClick={onOpen}><div className="task-icon"><ClipboardCheck size={23} /></div><div className="task-copy"><StatusChip tone="progress">In progress</StatusChip><h3>Morning Cleaning Round</h3><p><MapPin size={14} /> Main Sports Club <span>·</span> 08:00 – 10:30</p><div className="mini-progress"><i style={{ width: '43%' }} /></div><small>3 of 7 areas complete</small></div><ChevronRight className="task-arrow" size={20} /></button><div className="section-heading"><h2>Recent activity</h2></div><div className="activity"><CheckCircle2 size={19} /><div><b>Reception & Lobby</b><span>Approved by supervisor</span></div><time>Yesterday</time></div></div></section> }
function Stat({ number, label, tone }: { number: string; label: string; tone: string }) { return <div className={`stat stat-${tone}`}><strong>{number}</strong><span>{label}</span></div> }

function AssignmentsView({ tab, setTab, onBack, onOpen }: { tab: string; setTab: (s: string) => void; onBack: () => void; onOpen: () => void }) { return <section className="screen"><Header title="My assignments" onBack={onBack} /><div className="scroll-content"><div className="search-row"><div className="search"><Search size={18} /><input placeholder="Search assignments" /></div><button className="filter-button" aria-label="Filter"><Filter size={19} /></button></div><div className="tabs">{['Today', 'Upcoming', 'History'].map((item) => <button key={item} className={tab === item ? 'active' : ''} onClick={() => setTab(item)}>{item}</button>)}</div><p className="list-count">{tab === 'Today' ? '3 assignments' : tab === 'Upcoming' ? 'Next 7 days' : 'Past assignments'}</p><div className="assignment-list">{assignments.map((assignment, i) => <button className="assignment-card" key={assignment.title} onClick={onOpen}><div className="card-top"><StatusChip tone={assignment.tone}>{assignment.status}</StatusChip><span className="date-label">{i === 2 ? '25 Aug' : '26 Aug 2026'}</span></div><h3>{assignment.title}</h3><p><MapPin size={14} /> {assignment.place}</p><div className="card-bottom"><span><Clock3 size={14} /> {assignment.time}</span><b>{assignment.progress}</b></div><div className="mini-progress"><i style={{ width: i === 0 ? '43%' : i === 2 ? '100%' : '4%' }} /></div></button>)}</div></div></section> }

function DetailView({ rtl, setRtl, items, completed, allDone, toggle, onBack, onSubmit }: { rtl: boolean; setRtl: (v: boolean) => void; items: Item[]; completed: number; allDone: boolean; toggle: (i: number) => void; onBack: () => void; onSubmit: () => void }) { return <section className="screen detail-screen"><Header title="Assignment detail" onBack={onBack} action={<button className="lang-icon" onClick={() => setRtl(!rtl)}><Languages size={18} /><span>{rtl ? 'EN' : 'عربي'}</span></button>} /><div className="scroll-content detail-content"><div className="detail-title"><p className="eyebrow">26 AUGUST 2026 · 08:00 – 10:30</p><h1>{rtl ? 'جولة التنظيف الصباحية' : 'Morning Cleaning Round'}</h1><p><MapPin size={15} /> {rtl ? 'النادي الرياضي الرئيسي' : 'Main Sports Club'}</p></div><div className="progress-summary"><div><b>{completed} <span>/ 7</span></b><small>{rtl ? 'مناطق مكتملة' : 'areas complete'}</small></div><div className="big-progress"><i style={{ width: `${(completed / 7) * 100}%` }} /></div></div><div className="checklist-heading"><h2>{rtl ? 'قائمة التحقق' : 'Checklist'}</h2><span>{allDone ? 'Ready to submit' : `${7 - completed} remaining`}</span></div><div className="checklist">{items.map((item, i) => <button className={`check-row ${item.rejected ? 'is-rejected' : ''}`} key={item.name} onClick={() => toggle(i)}><span className={`checkbox ${item.done ? 'checked' : ''}`}>{item.done && <Check size={16} />}</span><span className="row-content"><b>{rtl ? ['المدخل الرئيسي والاستقبال','غرفة تبديل الرجال','غرفة تبديل النساء','أرضية الصالة الرياضية','دورات المياه والاستحمام','ممر الموظفين','نقطة جمع النفايات'][i] : item.name}</b>{item.photo && <small><ImagePlus size={13} /> Photo required</small>}{item.rejected && <em>{rtl ? 'يرجى إعادة التقاط الصورة: الأرضية تبدو مبللة.' : item.rejected}</em>}</span>{item.photo && !item.rejected && <ImagePlus className="row-photo" size={20} />}</button>)}</div></div><div className="bottom-action"><button className="primary-button" disabled={!allDone} onClick={onSubmit}>Submit & Sign <PenLine size={18} /></button>{!allDone && <small>Complete all required areas to submit</small>}</div></section> }

function SignatureView({ rtl, signature, setSignature, onBack, onSubmit }: { rtl: boolean; signature: boolean; setSignature: (v: boolean) => void; onBack: () => void; onSubmit: () => void }) { return <section className="screen"><Header title={rtl ? 'التوقيع' : 'Sign submission'} onBack={onBack} /><div className="scroll-content signature-content"><div className="signature-intro"><div className="success-icon"><PenLine size={22} /></div><p className="eyebrow">{rtl ? 'تأكيد العمل' : 'CONFIRM YOUR WORK'}</p><h1>{rtl ? 'أضف توقيعك' : 'Add your signature'}</h1><p>{rtl ? 'سيتم إرسال سجل التنظيف للمراجعة.' : 'This creates a signed record of your cleaning round.'}</p></div><label className="signer-label">{rtl ? 'الموظف' : 'Signing as'}<div className="signer"><UserRound size={18} /><b>Ahmed Saleh</b><ShieldCheck size={17} /></div></label><div className="signature-pad" onPointerDown={() => setSignature(true)}><span>{signature ? 'Ahmed Saleh' : 'Sign here'}</span>{!signature && <div className="pad-line" />}</div><div className="pad-footer"><small><Clock3 size={14} /> 26 Aug 2026 · 10:42 AM</small><button className="text-button" onClick={() => setSignature(false)}>Clear</button></div><button className="primary-button" disabled={!signature} onClick={onSubmit}>{rtl ? 'إرسال' : 'Submit record'} <Check size={18} /></button></div></section> }

function Success({ onBack }: { onBack: () => void }) { return <main className="success-page"><div className="success-icon large"><Check size={34} /></div><p className="eyebrow">SUBMISSION RECEIVED</p><h1>Nice work, Ahmed.</h1><p>Your cleaning round has been submitted and is pending admin review.</p><button className="primary-button" onClick={onBack}>Back to assignments <ArrowRight size={18} /></button></main> }
function BottomNav({ active, onHome, onAssignments, onProfile }: { active: string; onHome: () => void; onAssignments: () => void; onProfile: () => void }) { return <nav className="bottom-nav"><button className={active === 'home' ? 'active' : ''} onClick={onHome}><Home size={21} /><span>Home</span></button><button className={active === 'assignments' ? 'active' : ''} onClick={onAssignments}><ClipboardCheck size={21} /><span>Assignments</span></button><button onClick={onProfile}><UserRound size={21} /><span>Profile</span></button></nav> }
function Profile({ onClose, rtl, setRtl, onLogout }: { onClose: () => void; rtl: boolean; setRtl: (v: boolean) => void; onLogout: () => void }) { return <div className="profile-overlay"><div className="profile-sheet" dir={rtl ? 'rtl' : 'ltr'}><div className="sheet-head"><h2>Profile</h2><button className="icon-button" onClick={onClose}><X size={20} /></button></div><div className="profile-identity"><div className="avatar big">AS</div><div><h3>Ahmed Saleh</h3><p>Housekeeping · Operations</p></div></div><div className="settings-list"><div><UserRound size={19} /><span>+966 50 123 4567<small>Phone number</small></span></div><div><CloudOff size={19} /><span>3 photos pending upload<small>Sync status</small></span><StatusChip tone="pending">Offline</StatusChip></div><div><Languages size={19} /><span>Language<small>{rtl ? 'Arabic' : 'English'}</small></span><button className="switch" onClick={() => setRtl(!rtl)}><i /></button></div><div><Settings size={19} /><span>Change password</span><ChevronRight size={18} /></div></div><button className="logout" onClick={onLogout}>Log out</button></div></div> }
